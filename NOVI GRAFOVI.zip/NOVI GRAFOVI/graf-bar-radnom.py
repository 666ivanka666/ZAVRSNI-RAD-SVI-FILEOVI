import matplotlib.pyplot as plot
import numpy as np

# randint function is used to generate 
# an array of size 5
# with random values in range 0-10
y = np.random.randint(10, size=(4))
# x-axis labels
x = np.array(["A", "B", "C", "D"])

plot.figure(figsize=(10, 8))
plot.bar(x, y, color = "violet")
plot.show()