import matplotlib.pyplot as plt

'''data = {'apples': 10, 'oranges': 15, 'lemons': 5, 'limes': 20}
names = list(data.keys())
values = list(data.values())'''

'''fig, axs = plt.subplots(1, 3, figsize=(9, 3), sharey=True)
axs[0].bar(names, values)
axs[1].scatter(names, values)
axs[2].plot(names, values)
fig.suptitle('Categorical Plotting')'''

temp = [0,40]
vlaga = [0,100]
ph = [1, 14]
lux = [200,1200]

fig, ax = plt.subplots()
ax.plot(ph, temp, label="temp")
ax.plot(ph, vlaga, label="vlaga")
ax.plot(ph, ph, label="ph")
ax.plot(ph, lux, label="lux")
ax.legend()

plt.show()