import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt


x = [1,2,3,4,5]
y = [8,12,4,2,6]
#Q06.61 Create a scatter plot with the following arrays of x pints and y points generated with NumPy's np.random.randint() function.


x = np.random.randint(20)
y = np.random.randint(20)
#Q06.62 Use the code below to create two arrays of semi-focused random points.


x1 = 1.5 * np.random.randn(150) + 10
y1 = 1.5 * np.random.randn(150) + 10
x2 = 1.5 * np.random.randn(150) + 4
y2 = 1.5 * np.random.randn(150) + 4
x = np.append(x1,x2)
y = np.append(y1,y2)