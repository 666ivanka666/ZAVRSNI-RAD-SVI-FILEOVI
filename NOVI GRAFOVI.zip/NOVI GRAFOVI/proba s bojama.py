import matplotlib.pyplot as plt, random
n = int(input("Enter the values:"))
values = []
color = []
for i in range(n):
    x = int(input("Enter the number to be updated in the list: "))
    values.append(x)
    r = random.random()
    g = random.random()
    b = random.random()
    color.append([r, g, b])
plt.pie(values,colors=color);
plt.show()