''''import matplotlib.pyplot as plot
import numpy as np

# randint function is used to generate 
# an array of size 5
# with random values in range 0-10
y = np.random.randint(10, size=(4))
colors = [
      "#ff0000", # RGB string notation
      (0, 0, 1), # RGB tuple notation
      "yellow",  # X11 color name
      "c",       # short hand color string 
      "#00FF00"
      ]

plot.figure(figsize=(15, 12))
plot.pie(y, colors=colors)
plot.show() '''


import matplotlib.pyplot as plot
import numpy as np

# randint function is used to generate 
# an array of size 5
# with random values in range 0-10
y = np.random.randint(18, size=(4))
colors = [
      "violet", # colours
      'purple', 
      "black",  
      "grey",       
     
      ]

plot.figure(figsize=(10, 5))
plot.pie(y, colors=colors)
plot.show()




#https://www.scaler.com/topics/how-to-customize-plots-in-matplotlib/