

from PIL import Image, ImageTk
import tkinter as tk
from tkinter import *
import matplotlib.pyplot as plt
import numpy as np



import matplotlib.pyplot as plot
import numpy as np

# randint function is used to generate 
# an array of size 15 
# with random values in range 0-100
x = np.random.randint(100, size=(15))
y = np.random.randint(100, size=(15))
plot.scatter(x, y, color = 'red') # X11 notation of color

x = np.random.randint(100, size=(15))
y = np.random.randint(100, size=(15))
plot.scatter(x, y, color = '#00ff00') # RGB string notation

x = np.random.randint(100, size=(15))
y = np.random.randint(100, size=(15))
plot.scatter(x, y, color = (0, 0, 1)) # RGB tuple notation 

x = np.random.randint(100, size=(15))
y = np.random.randint(100, size=(15))
plot.scatter(x, y, color = '#ffff00aa') # RGBA string notation

plot.show()