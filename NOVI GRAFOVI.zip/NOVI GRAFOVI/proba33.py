# library
import matplotlib.pyplot as plt
plt.rcParams["figure.figsize"] = (10,5)
# create random data
values=[12,11,3,30]
 
# Create a pieplot
plt.pie(values)
plt.show()
